﻿using Microsoft.SqlServer.Server;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Data;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            Assert.IsTrue(true);
        }
        [TestMethod]
        public void TestMethod2()
        {
            List<KeyValuePair<string, int>> Top20 = new List<KeyValuePair<string, int>>();
            Top20 = piz.pizza.GetTop20Toppings();
            List<Totals> For_View = new List<Totals>();

            for (int ii = 0; ii < Top20.Count; ii++)
            {
                Totals t = new Totals();
                t.name = Top20[ii].Key;
                t.count = Top20[ii].Value;
                For_View.Add(t);
            }

            //// Create the record and specify the metadata for the columns.
            //SqlDataRecord record = new SqlDataRecord(
            //    new SqlMetaData("ID", SqlDbType.Int),
            //    new SqlMetaData("Name", SqlDbType.NVarChar, 1024),
            //    new SqlMetaData("Amount", SqlDbType.NVarChar, 1024)
            //    );

            //// Mark the begining of the result-set.
            //SqlContext.Pipe.SendResultsStart(record);



            //// Send 10 rows back to the client.
            //int k = 1;
            //foreach (var my_item in For_View)

            //{
            //    // Set values for each column in the row.
            //    record.SetInt32(0, k);
            //    record.SetString(1, my_item.name);
            //    record.SetString(2, my_item.count.ToString());
            //    k++;
            //    // Send the row back to the client.
            //    SqlContext.Pipe.SendResultsRow(record);
            //}

            //// Mark the end of the result-set.
            //SqlContext.Pipe.SendResultsEnd();

        }
    }

    public class Totals
    {
        public string name;
        public int count;
    }
}
