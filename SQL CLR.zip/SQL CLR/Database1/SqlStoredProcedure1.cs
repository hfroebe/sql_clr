using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;
using System.Net;
using System.Text;
using System.Xml;
using Microsoft.SqlServer.Server;


public partial class StoredProcedures
{

    public static List<KeyValuePair<string, int>> Top20 { get; set; }
    public static List<Totals> For_View { get; set; }

    [Microsoft.SqlServer.Server.SqlProcedure]
    public static void spGetINRRates()
    {
        //HttpWebRequest request = (HttpWebRequest)WebRequest.Create("http://c-sharpcorner.com/CurrencyRate/INR");

        //request.Method = "GET";
        //request.ContentLength = 0;
        //request.Credentials = CredentialCache.DefaultCredentials;
        //request.ContentType = "application/xml";
        //request.Accept = "application/xml";

        //using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
        //{
        //    using (Stream receiveStream = response.GetResponseStream())
        //    {
        //        using (StreamReader readStream = new StreamReader(receiveStream, Encoding.UTF8))
        //        {
        //            string strContent = readStream.ReadToEnd();
        //            XmlDocument xdoc = new XmlDocument();
        //            xdoc.LoadXml(strContent);



        Top20 = piz.pizza.GetTop20Toppings();
        For_View = new List<Totals>();

        for (int ii = 0; ii < Top20.Count; ii++)
        {
            Totals t = new Totals();
            t.name = Top20[ii].Key;
            t.count = Top20[ii].Value;
            For_View.Add(t);
        }


                    // Create the record and specify the metadata for the columns.
                    SqlDataRecord record = new SqlDataRecord(
                        new SqlMetaData("ID", SqlDbType.Int),
                        new SqlMetaData("Name", SqlDbType.NVarChar, 1024),
                        new SqlMetaData("Amount", SqlDbType.NVarChar, 1024)
                        );

                    // Mark the begining of the result-set.
                    SqlContext.Pipe.SendResultsStart(record);



        // Send 10 rows back to the client.
        int k = 1;
        foreach (var my_item in For_View)

        {
            // Set values for each column in the row.
            record.SetInt32(0, k);
            record.SetString(1, my_item.name);
            record.SetString(2, my_item.count.ToString());
            k++;
            // Send the row back to the client.
            SqlContext.Pipe.SendResultsRow(record);
        }
          
        // Mark the end of the result-set.
        SqlContext.Pipe.SendResultsEnd();


     }
        

    
}
public class Totals
{
    public string name;
    public int count;
}


