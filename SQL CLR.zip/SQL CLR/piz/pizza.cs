﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace piz
{
    public class pizza
    {
        public static List<KeyValuePair<string, int>> GetTop20Toppings()
        {
            ServicePointManager.Expect100Continue = true;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            string url = "https://www.olo.com/pizzas.json";
            var webClient = new WebClient();
            var jsonData = string.Empty;

            jsonData = webClient.DownloadString(url);


            List<string> individual_toppings = new List<string>();

            Newtonsoft.Json.Linq.JArray jArray = Newtonsoft.Json.Linq.JArray.Parse(jsonData);

            foreach (Newtonsoft.Json.Linq.JObject item in jArray)
            {
                string topping = item.GetValue("toppings").ToString();


                string topping_adjusted = RemoveSpecialChars(topping).TrimStart();

                if (topping_adjusted.Contains(","))
                {

                    char[] delimiterChars = { ' ', ',', '.', ':', '\t' };
                    char[] delimiterChars2 = {','};

                    string[] individual_list = topping_adjusted.Split(delimiterChars2);
                    List<string> temp = new List<string>();
                    temp = individual_list.ToList();
                    foreach (var topping_in_group in temp)
                    {
                        individual_toppings.Add(topping_in_group);
                    }
                }
                else
                {
                    individual_toppings.Add(topping_adjusted);
                }
            }

            List<string> unique_toppings = new List<string>();

            unique_toppings = individual_toppings.Distinct().ToList();


            List<int> total_counts = new List<int>();

            int individual_count = 0;

            for (int k = 0; k < unique_toppings.Count; k++)
            {
                for (int i = 0; i < individual_toppings.Count; i++)
                {
                    if (unique_toppings[k] == individual_toppings[i])
                    {
                        individual_count++;
                    }
                }
                total_counts.Add(individual_count);
                individual_count = 0;

            }

            Dictionary<string, int> totals = new Dictionary<string, int>();

            totals = unique_toppings.Zip(total_counts, (k, v) => new { k, v })
                                    .ToDictionary(x => x.k, x => x.v);

            var top20names = totals.OrderByDescending(d => d.Value).Take(20).ToList();

            return top20names;

        }



        public static string RemoveSpecialChars(string str)
        {

            string[] chars = new string[] { "\r\n", ".", "/", "!", "@", "#", "$", "%", "^", "&", "*", "'", "\"", ";", "_", "(", ")", ":", "|", "[", "]" };

            for (int i = 0; i < chars.Length; i++)
            {
                if (str.Contains(chars[i]))
                {
                    str = str.Replace(chars[i], "");
                }
            }
            return str;
        }
    }
}
