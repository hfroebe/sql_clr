
CREATE PROCEDURE dbo.spGetINRRates      
AS EXTERNAL NAME webdata.StoredProcedures.spGetINRRates;  