

USE FTTM_laptop
GO 

CREATE ASSEMBLY [webdata]
FROM N'C:\stuff\usb\C#\SQL CLR\Database1\bin\Debug\Database1.dll' WITH PERMISSION_SET = UNSAFE
GO 